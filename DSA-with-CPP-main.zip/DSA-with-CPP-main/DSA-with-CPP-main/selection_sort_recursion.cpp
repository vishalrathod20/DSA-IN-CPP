#include<iostream>
using namespace std ;

void selection_sort(int * arr , int n)
{
    if(n==0||n==1)
    {
        return ;
    }
    
    
}